package com.example.mainproject

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class App2Activity : AppCompatActivity() {
    lateinit var Buttonsms: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app2)
        Buttonsms=findViewById(R.id.Btn_Sms)
        Buttonsms.setOnClickListener {
            val uri = Uri.parse("smsto:0726806487")

            val intent = Intent(Intent.ACTION_SENDTO, uri)

            intent.putExtra("Hello", "How is todays weather")

            startActivity(intent)

        }

    }
}