package com.example.mainproject

import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class App4Activity : AppCompatActivity() {
    lateinit var Buttondial: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Buttondial=findViewById(R.id.Btn_Dial)
        Buttondial.setOnClickListener {
            val phone = "+254726806487"

            val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null))

            startActivity(intent)

        }
        setContentView(R.layout.activity_app4)
    }
}