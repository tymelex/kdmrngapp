package com.example.mainproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class App5Activity : AppCompatActivity() {
    lateinit var Buttonstk: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_app5)
        Buttonstk=findViewById(R.id.Btn_Stk)
        Buttonstk.setOnClickListener {
            val simToolKitLaunchIntent =
                applicationContext.packageManager.getLaunchIntentForPackage("com.android.stk")

            simToolKitLaunchIntent?.let { startActivity(it) }

        }

    }
}