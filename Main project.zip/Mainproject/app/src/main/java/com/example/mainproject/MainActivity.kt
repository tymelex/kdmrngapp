package com.example.mainproject

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    lateinit var btnapp1:Button
    lateinit var btnapp2:Button
    lateinit var btnapp3:Button
    lateinit var btnapp4:Button
    lateinit var btnapp5:Button
    lateinit var btnapp6:Button
    lateinit var btnapp7:Button
    lateinit var btnapp8:Button
    lateinit var btnapp9:Button
    lateinit var btnapp10:Button



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnapp1=findViewById(R.id.button1)
        btnapp2=findViewById(R.id.button2)
        btnapp3=findViewById(R.id.button3)
        btnapp4=findViewById(R.id.button4)
        btnapp5=findViewById(R.id.button5)
        btnapp6=findViewById(R.id.button6)
        btnapp7=findViewById(R.id.button7)
        btnapp8=findViewById(R.id.button8)
        btnapp9=findViewById(R.id.button9)
        btnapp10=findViewById(R.id.button10)


        btnapp1.setOnClickListener {
            val intent = Intent(this,App1Activity::class.java)
            startActivity(intent)
        }
        btnapp2.setOnClickListener {
            val intent = Intent(this,App2Activity::class.java)
            startActivity(intent)
        }

        btnapp3.setOnClickListener {
            val intent = Intent(this,App3Activity::class.java)
            startActivity(intent)
        }
        btnapp4.setOnClickListener {
            val intent = Intent(this,App4Activity::class.java)
            startActivity(intent)
        }
        btnapp5.setOnClickListener {
            val intent = Intent(this,App5Activity::class.java)
            startActivity(intent)
        }
        btnapp6.setOnClickListener {
            val intent = Intent(this,App6Activity::class.java)
            startActivity(intent)
        }
        btnapp7.setOnClickListener {
            val intent = Intent(this,App7Activity::class.java)
            startActivity(intent)
        }
        btnapp8.setOnClickListener {
            val intent = Intent(this,App8Activity::class.java)
            startActivity(intent)
        }
        btnapp9.setOnClickListener {
            val intent = Intent(this,App9Activity::class.java)
            startActivity(intent)
        }
        btnapp10.setOnClickListener {
            val intent = Intent(this,App10Activity::class.java)
            startActivity(intent)
        }






    }
}